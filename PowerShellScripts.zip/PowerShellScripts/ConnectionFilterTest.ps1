using namespace System.Net
# Set a parameter
param($Request)

# Instantiate Credentials
$username = 'ArunDemoUser@Testenvhexa.com'
$password = ConvertTo-SecureString 'Hexaware@123' -AsPlainText -Force
$psCred = New-Object System.Management.Automation.PSCredential -ArgumentList ($username, $password)

# Import the MSOnline Module and establish a session to Exchange Online
Import-Module MSOnline

$Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $psCred -Authentication Basic -AllowRedirection
Import-PSSession $Session -DisableNameChecking

#Create a variable to pass a value from the Request to Powershell

$identity = $Request.Query.Identity
Import-Module ExchangeOnlineManagement

$AllowIPAddressesList = (Get-HostedConnectionFilterPolicy "Default").IPAllowList

$ConnectionFilterPolicy = "Default"

$AllowIPAddresses = "192.169.3.1/24,192.169.4.1/24,192.168.4.1-192.168.4.5"
$BlockIPAddresses = "193.168.1.10-15,193.169.3.1/24"

$AllowIPAddressesArray = $AllowIPAddresses -split ","
$BlockIPAddressesArray = $BlockIPAddresses -split ","



if ($AllowIPAddressesArray) {
foreach ($CurIPAllow in $AllowIPAddressesArray) {
Write "Set-HostedConnectionFilterPolicy 'Default' -IPAllowList @{Add='$CurIPAllow'}"
$command = "Set-HostedConnectionFilterPolicy 'Default' -IPAllowList @{Add="+$CurIPAllow+"}"
Invoke-Expression -Command "Set-HostedConnectionFilterPolicy 'Default' -IPBlockList @{Add='$CurIPAllow'}"
}
}

Write $AllowIPAddressesList

#Set-HostedConnectionFilterPolicy "Default" -IPAllowList $parameter

#Set-HostedConnectionFilterPolicy "Default" -IPAllowList @{Add="192.168.2.10","192.169.3.0/24","192.168.4.1-192.168.4.5";Remove="192.168.1.10"}

#Terminate the Exchange Session
Remove-PSSession $Session