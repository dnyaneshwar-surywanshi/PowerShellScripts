Param  
(  
    [Parameter (Mandatory = $false)]  
    [object] $WebhookData  
)

[bool]$jobStatus = 0

try
{   
    # If runbook was called from Webhook, WebhookData will not be null.  
    if ($WebhookData) {  
        # Collect properties of WebhookData  
        $WebhookName = $WebHookData.WebhookName  
        $WebhookHeaders = $WebHookData.RequestHeader  
        $WebhookBody = $WebHookData.RequestBody  
        $Input = (ConvertFrom-Json -InputObject $WebhookBody)
        
        $Input
        
       # Instantiate Credentials
        $UserName = $Input.UserName
        $Password = ConvertTo-SecureString $Input.Password -AsPlainText -Force
        $psCred = New-Object System.Management.Automation.PSCredential -ArgumentList ($UserName, $Password)   
		Connect-SPOService -Url https://$Input.OrganizationName-admin.sharepoint.com -Credential $psCred
        
	    Add-SPOUser -Site $Input.SiteUrl -LoginName $Input.EmailId -Group $Input.GroupName
		
    }  
    else  
    {  
        Write-Error -Message 'Runbook was not started from Webhook' -ErrorAction stop  
    }    

}
Catch
{  
    "In Catch Block, Error Message Below...."
     $errorMessage = $_.Exception.Message  
	 $errorMessage
     throw $errorMessage    
 
}
finally
{ 
    
}
