$UserName="dnyanesh@dnyaneshtechno.onmicrosoft.com"
$Password = ConvertTo-SecureString  "Password@1122" -AsPlainText -Force
$URL="https://dnyaneshtechno.sharepoint.com/sites/oegsupport"
$useSamePermissionsAsParentSite = $true 
$SPCredentials = New-Object -typename System.Management.Automation.PSCredential -argumentlist $UserName,$Password
  
 
Connect-SPOService -Url https://dnyaneshtechno-admin.sharepoint.com -Credential $SPCredentials

 $SPOCredentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($UserName, $Password)
 $context = New-Object Microsoft.SharePoint.Client.ClientContext($URL)
 $context.Credentials = $SPOCredentials 
  
      #Specify Subsite details
    $WebCI = New-Object Microsoft.SharePoint.Client.WebCreationInformation
    $WebCI.Title = "My Fifth Web"
    $WebCI.WebTemplate = "STS#0" #Team Site
    $WebCI.Url = "MyFifthWeb"
    $WebCI.useSamePermissionsAsParentSite = $useSamePermissionsAsParentSite
    #sharepoint online create subsite powershell
    $SubWeb = $Context.Web.Webs.Add($WebCI)
    $Context.ExecuteQuery()
