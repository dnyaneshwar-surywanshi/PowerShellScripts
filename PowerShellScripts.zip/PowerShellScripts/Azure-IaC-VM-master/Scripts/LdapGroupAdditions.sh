#/bin/bash

# Script Input
# ./add_group TLA Environment Cloud
# TLA: The Three Letter Abbreviation for the workload
# Environment: prod, test, uat, dev
# Cloud: azure, gcp (all lower case)

tla=$1
environment=$2
cloud=$3

if [ "$cloud" == "azure" ]
then
    csc="az"
elif [ "$cloud" == "gcp" ]
then
    csc="gc"
fi

if [ "$environment" == "dev" ] || [ "$environment" == "test" ] || [ "$environment" == "uat" ]
then
    env_type="nonprod"
elif [ "$environment" == "prod" ]
then
    env_type="prod"
fi

group_name=$(getent group lsec${csc}${tla}${env_type}app | cut -d: -f1)
group_info=$(getent group lsec${csc}${tla}${env_type}app | cut -d: -f1,2,3)


if [ -z "$environment" ] || [ -z "$csc" ] || [ -z "$tla" ]
then
    echo "Environment, TLA, or Short Code is empty"
else
    grep -qxF "%$group_name       ALL=(ALL) ALL" /etc/sudoers || echo "%$group_name       ALL=(ALL) ALL" >> /etc/sudoers
    grep -qxF "$group_info:" /etc/group || echo "$group_info:" >> /etc/group

    grep "%${group_name}" /etc/sudoers 
    grep "${group_name}" /etc/group
fi
