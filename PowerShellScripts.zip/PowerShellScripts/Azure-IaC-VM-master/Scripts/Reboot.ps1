param( 
    $Subscription,
    $ResourceGroupName
)

workflow Restart-AzVMs ($Subscription, $ResourceGroupName)
{
    Select-AzSubscription $Subscription

    $VMs = Get-AzVM -ResourceGroupName $ResourceGroupName

     if(!$VMs) { 
        Write-Output "No VMs were found in the RG." 
 
     } else { 
 
        Foreach -parallel ($VM in $VMs) { 
        Restart-AzVM -ResourceGroupName "$ResourceGroupName" -Name $VM.Name -Force -ErrorAction SilentlyContinue 
        }
     }
}

# Wait for 2min so as to give the server time to reboot
Start-Sleep -s 120
