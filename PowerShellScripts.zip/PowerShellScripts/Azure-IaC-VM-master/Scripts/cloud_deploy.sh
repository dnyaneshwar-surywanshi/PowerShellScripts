# VARIABLES SECTION
localgroup=$1
echo -e "Creating Local Group $localgroup"
localuser=$2 
echo -e "Creating Local User $localuser"
DOMAIN=$4
echo -e "Domain to join is $DOMAIN"
disksize=$5
echo -e "Disk Size is $disksize"
hostname=$6
echo -e "Hostname is: $hostname"
ip=$(/sbin/ip -o -4 addr list eth0 | awk '{print $4}' | cut -d/ -f1)
echo -e "IP Address is $ip"

# Set DNS server
echo nameserver 10.17.36.20 >> /etc/resolv.conf

# Create user and group
password="$3"
pass=$(perl -e 'print crypt($ARGV[0], "password")' $password)

groupadd $1
useradd -m $2 -g $1 -p $pass

# Add user/group to sudoers
echo "$2        ALL=(ALL) ALL" >> /etc/sudoers
echo "$1        ALL=(ALL) ALL" >> /etc/sudoers

exec 3>&2
exec 2> /dev/null

# Disk partitioning
echo "n
p


w" | fdisk /dev/sda
partprobe
cat /proc/partitions
pvcreate /dev/sda4
vgextend vg00 /dev/sda4
lvextend -L 40g /dev/vg00/lv_opt
lvextend -L 40g /dev/vg00/lv_var
lvextend -L 10g /dev/vg00/lv_home
xfs_growfs /opt
xfs_growfs /var
xfs_growfs /home

# Part 2nd disk
echo "n
p



w" | fdisk /dev/sdc
partprobe
pvcreate /dev/sdc1
vgcreate appdata /dev/sdc1

# Update with disk size here - needs to be 1g smaller than spec'd in Azure
lvcreate -L $disksize -n appdata_lv appdata
mkdir /appdata
mkfs.xfs /dev/appdata/appdata_lv
echo /dev/appdata/appdata_lv /appdata 	xfs defaults 0 0 >> /etc/fstab
mount -a
chown -R $2:$1 /appdata
chmod 755 /appdata

exec 2>&3

# Prepare for Satallite server add
# /etc/resolv.conf
/bin/cp -p /etc/resolv.conf.wow /etc/resolv.conf

# Updating files here
HOSTFILE=/etc/hosts
echo -e "$IP\t${HOSTNAME}.$DOMAIN $HOSTNAME" >> $HOSTFILE

# Update hostname
echo ${HOSTNAME}.$DOMAIN > /etc/hostname

# udate root password
sed -i 's=root.*=root:$1$b.pumhUk$1EBTz.Bs6kL.Goixde/9T0:16906:0:99999:7:::=' /etc/shadow

rm -f /etc/sudoers.d/waagent