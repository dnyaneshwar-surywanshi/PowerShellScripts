param (
    $vmNamePrefix,
    $vmOffset = 0,
    $vmNumberOfInstances = 0,
    $ResourceGroupName,
    $location,
    $StorageType = "Premium_LRS",
    $DataDisk1Size = 0,
    $DataDisk2Size = 0,
    $DataDisk3Size = 0,
    $DataDisk4Size = 0,
    $DataDisk5Size = 0,
    $DataDisk6Size = 0,
    $DataDisk7Size = 0,
    $DataDisk8Size = 0,
    $DataDisk9Size = 0
)

### Functions ##########################################################

function Prov-Disk ($vmInstance, $StorageType, $location, $ResourceGroupName) 
{
    $DiskObjs = $vmInstance.disks
    $DiskNum = 1
    Foreach ($DiskObj in $DiskObjs)
    {
        $DiskObjName = $vmInstance.vmName + "-DataDisk$DiskNum"
        Write-host -ForegroundColor Yellow "Provisioning Disk $DiskObjName for $($vmInstance.vmName) with $DiskObj capacity"
        $DataDiskConfig = New-AzDiskConfig -SkuName $StorageType -Location $location -CreateOption Empty -DiskSizeGB $DiskObj
        $DataDisk = New-AzDisk -DiskName $DiskObjName -Disk $DataDiskConfig -ResourceGroupName $ResourceGroupName
        $vmObj = Get-AzVm -Name $vmInstance.vmName -ResourceGroupName $ResourceGroupName
        Add-AzVMDataDisk -VM $vmObj -Name $DiskObjName -CreateOption Attach -ManagedDiskId $DataDisk.id -Lun $DiskNum
        Update-AzVM -VM $vmObj -ResourceGroupName $ResourceGroupName

        $DiskNum++
    }
}
$export_ProvDisk = [scriptblock]::Create(@"
    Function Prov-Disk { ${function:Prov-Disk} }
"@)

#########################################################################

Write-host -ForegroundColor Yellow "Lets Start the provisioning process here"

# Location of VM / disk(s)
If ($Location -eq "AustraliaEast"){ $RegionPrefix = [int]00000}
If ($Location -eq "AustraliaSoutheast"){ $RegionPrefix = [int]10000}

# Remove Disk Entries with 0GB
$Disks = $DataDisk1Size,$DataDisk2Size,$DataDisk3Size,$DataDisk4Size,$DataDisk5Size,$DataDisk6Size,$DataDisk7Size,$DataDisk8Size,$DataDisk9Size
$Disks = $Disks.Where({ $_ -ne 0})

# If no disks in the array, lets get outta here
If ($Disks.Count -lt 1){ exit }

# Lets create a vmname / Disk array to map
$vmInstanceArray = @()
$vmOffset = $vmOffset-1 # the way this is handled in PoSH is different from arm, hence the -1
For ($i=1; $i -le $vmNumberOfInstances; $i++)
{
    $vmInstanceArray += @(
        [pscustomobject]@{
            vmName = $vmNamePrefix + ("{0:D5}" -f ($RegionPrefix+$vmoffset+$i))
            disks = $Disks
            }
    )
}

# Time to loop through each Instance
Foreach ($vmInstance in $vmInstanceArray)
{
    Start-Job -Name "$($vmInstance.vmName)-DiskConfig" -InitializationScript $export_ProvDisk -ScriptBlock {
        $vmInstance = $args[0]
        $StorageType = $args[1]
        $location = $args[2]
        $ResourceGroupName = $args[3]
        Prov-Disk -vmInstance $vmInstance -StorageType $StorageType -location $location -ResourceGroupName $ResourceGroupName
    } -ArgumentList $vmInstance, $StorageType, $location, $ResourceGroupName
}

While ((Get-Job -State Running).Count -gt 0){
    Write-Host -ForegroundColor DarkCyan "Waiting for Disk Provisioning to complete, waiting 15secs...."
    Get-Job
    sleep -Seconds 15
    cls
}

Get-Job | Receive-Job -Keep