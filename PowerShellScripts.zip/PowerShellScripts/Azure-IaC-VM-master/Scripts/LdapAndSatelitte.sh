rheljoinpw=$1

# Install Uim Agent
uim_uri="https://armautomationartifacts.blob.core.windows.net/uim/uimagent-1.0-0.x86_64.rpm$2"
uim_file="/root/uimagent-1.0.0.x86_64.rpm"
uim_package=$(rpm -qa | grep -i uim)

echo $uim_uri

# If an old package exists uninstall it
if [ ! -z "$uim_package" ];
then
    echo "Uninstalling Package: $uim_package"
    rpm -e $uim_package
fi

# Download the agent if it does exist
if [ -f "$uim_file"];
then
    echo "$The file uim_file exists. skipping download"
else
    echo "Downloading $uim_file"
    wget -O $uim_file "$uim_uri"
fi

if [ ! -f "/etc/init.d/nimbus" ];
then
    echo "Installing Package: UIM Agent"
    rpm -ivh $uim_file
    if [ -f "/etc/init.d/nimbus" ];
    then
        echo "Checking Services: nimbus"
        systemctl restart nimbus.service
        systemctl status nimbus.service
    fi
fi

# Add to Satelite Server
/root/bootstrap.py -l azureadmin -p $rheljoinpw -s ncdlsatisp0010.woolworths.com.au -o 1-WOOLWORTHS -L AZURE -g RHEL76_AZURE --activationkey=1-azure76 P --download-method=http --release=7Server  --force

 # Run checks to ensure registered
subscription-manager list --consumed
subscription-manager status
subscription-manager repos
df -h

# LDAP Configuration
function SCRIPT_EXIT
{
    exit 0;
}
PACKS="openldap authconfig openldap-clients nss-pam-ldapd uimagent"
for i in $PACKS
do
if ! rpm -qa | grep -w $i
then
yum install $i -y
fi
if ! rpm -qa | grep -w $i
then
SCRIPT_EXIT
fi
done

# Checking certificates exists or not
path=/etc/openldap/cacerts
file1="$path/ldap_ncdlldpisp0001.cert"
file2="$path/ldap_ncdlldpisp0002.cert"
file3="$path/root.pem"
file4="$path/4ada2294.0"
file5="$path/1667dc46.0"
file6="$path/8fdd552a.0"
if [ ! -d $path ]
then
    mkdir -P /etc/openldap/cacerts
    cd $path
    wget https://ncdlsatisp0010.woolworths.com.au/pub/ldap_ncdlldpisp0001.cert -P /etc/openldap/cacerts
    wget https://ncdlsatisp0010.woolworths.com.au/pub/ldap_ncdlldpisp0002.cert -P /etc/openldap/cacerts
    wget https://ncdlsatisp0010.woolworths.com.au/pub/root.pem -P /etc/openldap/cacerts
if [[ -f "$file1" && -f "$file2" && -f "$file3" ]]
    then
        if [[ -f "$file4" && -f "$file5" && -f "$file6" ]]
        then
            echo "Rehashing files also exists"
        else
            cacertdir_rehash $path ;
        fi
        if [[ -f "$file4" && -f "$file5" && -f "$file6" ]]
        then
            echo "Rehashing files also exists"
        else
            echo " [ERROR] Not able to create rehasing files ! ";
SCRIPT_EXIT
        fi
fi

else
if [[ -f "$file1" && -f "$file2" && -f "$file3" ]]
    then
        if [[ -f "$file4" && -f "$file5" && -f "$file6" ]]
        then
            echo "Rehashing files also exists"
        else
            cacertdir_rehash $path ;
        fi
        if [[ -f "$file4" && -f "$file5" && -f "$file6" ]]
        then
            echo "Rehashing files also exists"
        else
            SCRIPT_EXIT
        fi
    else
    wget https://ncdlsatisp0010.woolworths.com.au/pub/ldap_ncdlldpisp0001.cert -P /etc/openldap/cacerts
    wget https://ncdlsatisp0010.woolworths.com.au/pub/ldap_ncdlldpisp0002.cert -P /etc/openldap/cacerts
    wget https://ncdlsatisp0010.woolworths.com.au/pub/root.pem -P /etc/openldap/cacerts
    cacertdir_rehash $path ;
    if [[ -f "$file4" && -f "$file5" && -f "$file6" ]]
        then
        echo "Rehashing files also exists"
        else
        SCRIPT_EXIT
    fi

    # Authconfig command
    authconfig --enableldap --ldapserver="ldaps://rhldap-prd.gss.woolworths.com.au/ ldaps://ncdlldpisp0101.woolworths.com.au/ ldaps://ncdlldpisp0201.woolworths.com.au/" --ldapbasedn="dc=linux,dc=prod,o=woolies" --update

    if [ $? -eq 0 ]
        then
            echo " LDAP Configured Successfully !";
        else
            echo " [ERROR] unable to configure LDAP ! ";
            SCRIPT_EXIT;
    fi
fi
fi
