param (
    $ConfigureSQLdisks = "False",
    $MsServerRoles,
    $LocalAdmins
)

$DriveLetters = @{
    E = "Maint" #smallest
    T = "Temp"  #small
    F = "Log"   #large
    H = "Data"  #largest
}

# Build Array of administration!
$LocalAdmins = $LocalAdmins -split ', '
$LocalAdminGroup = @()
$LocalAdminGroup += $LocalAdmins
$LocalAdminGroup += "wowcorp\Azure-SOI-CloudEngineering-Owner"

# Change CD drive letter (E:) if exists
$drv = Get-WmiObject win32_volume -filter 'DriveLetter = "E:"'
$drv.DriveLetter = "L:"
$drv.Put() | out-null

# This section will configure Drive partitioning for SQL servers
If ($ConfigureSQLdisks -eq "True")
{
    Get-Disk | Where-Object partitionstyle -EQ 'raw' | Initialize-Disk -PartitionStyle MBR -PassThru
    $Disks = Get-Disk -FriendlyName "Msft Virtual Disk" | Sort-Object size
    $i = 0
    
    # 1. Create the "Maint" Drive
    $DriveLetter = "E"
    Clear-Disk -Number $Disks[$i].number -RemoveData -Confirm:$false
    Get-Disk -Number $Disks[$i].number | Initialize-Disk -PartitionStyle MBR
    New-Partition -DiskNumber $Disks[$i].number -UseMaximumSize -IsActive -DriveLetter $DriveLetter
    Format-Volume -DriveLetter $DriveLetter -FileSystem NTFS -NewFileSystemLabel $DriveLetters.$DriveLetter
    $i++
    
    # 2. Create the "Temp" Drive
    $DriveLetter = "T"
    Clear-Disk -Number $Disks[$i].number -RemoveData -Confirm:$false
    Get-Disk -Number $Disks[$i].DiskNumber | Initialize-Disk -PartitionStyle MBR
    New-Partition -DiskNumber $Disks[$i].number -UseMaximumSize -IsActive -DriveLetter $DriveLetter
    Format-Volume -DriveLetter $DriveLetter -FileSystem NTFS -NewFileSystemLabel $DriveLetters.$DriveLetter
    $i++
    
    # 3. Create the "Log" Drive
    $DriveLetter = "F"
    Clear-Disk -Number $Disks[$i].number -RemoveData -Confirm:$false
    Get-Disk -Number $Disks[$i].number | Initialize-Disk -PartitionStyle MBR
    New-Partition -DiskNumber $Disks[$i].number -UseMaximumSize -IsActive -DriveLetter $DriveLetter
    Format-Volume -DriveLetter $DriveLetter -FileSystem NTFS -NewFileSystemLabel $DriveLetters.$DriveLetter
    $i++
    
    # 4. Create the "Data" Drive
    $DriveLetter = "H"
    Clear-Disk -Number $Disks[$i].number -RemoveData -Confirm:$false
    Get-Disk -Number $Disks[$i].number | Initialize-Disk -PartitionStyle MBR
    New-Partition -DiskNumber $Disks[$i].number -UseMaximumSize -IsActive -DriveLetter $DriveLetter
    Format-Volume -DriveLetter $DriveLetter -FileSystem NTFS -NewFileSystemLabel $DriveLetters.$DriveLetter
    $i++
    
    # We also need to take care of our dba friends
    $LocalAdminGroup += "wowcorp\MSSQLAdmins"
}
# Aaand if we aren't a database server, lets do a generic label
Else
{
    Get-Disk | Where-Object partitionstyle -eq 'raw' | Initialize-Disk -PartitionStyle MBR -PassThru | New-Partition -AssignDriveLetter -UseMaximumSize | Format-Volume -FileSystem NTFS -NewFileSystemLabel "Data" -Confirm:$false
}

# Whats the time mr Wolf?
tzutil /s "AUS Eastern Standard Time"

# Add Local Administrators
Add-LocalGroupMember -Group "Administrators" -Member $LocalAdminGroup

# Install Windows Server Roles, if required
if ($MsServerRoles -ne "none")
{
    foreach ($MsServerRoles in $MsServerRoles)
    {
        Import-Module ServerManager
        Add-WindowsFeature $MsServerRoles -IncludeAllSubFeature -IncludeManagementTools
    }
}


# Enable Dynamic DNS Registration - for PTR record creation
$adapters = Get-WmiObject Win32_NetworkAdapterConfiguration -Filter "IPEnabled = 'True'"
$adapters.SetDynamicDNSRegistration($true,$true)


# Update Windows Patch Level
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
Install-Module PSWindowsUpdate -Confirm:$false -Force

# Create the Update Script 
$ForceWsus = New-Item -Path C:\Wsus\ForceWsus.ps1 -ItemType File -Force
Add-Content $ForceWsus '
$env:COMPUTERNAME
Import-Module PSWindowsUpdate
Get-Service wuauserv  | Start-Service
Install-WindowsUpdate -Install -AcceptAll -MicrosoftUpdate -forceinstall -AutoReboot -verbose > C:\Wsus\Install.log'

# Create (and initiate) the WSUS Update Scheduled Task
$User = "NT AUTHORITY\SYSTEM"
$Action = New-ScheduledTaskAction -Execute "PowerShell.exe" -Argument "C:\Wsus\ForceWsus.ps1" 
Register-ScheduledTask -TaskName "ForceWSUS" -User $User -Action $Action -RunLevel Highest -Force

Start-ScheduledTask -TaskName "ForceWSUS"

