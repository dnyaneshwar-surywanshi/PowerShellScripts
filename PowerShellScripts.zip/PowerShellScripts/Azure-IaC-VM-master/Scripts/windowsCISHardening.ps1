param (
    $ArtifactsSasToken
)

Write-Host "#DATA#"
Write-Host "START SCRIPT"
Write-Host "#DATA#"

$StopWatch = New-Object System.Diagnostics.Stopwatch
$StopWatch.Start()
Get-Date

$File = 'C:\Temp\ansible\ansible_playbooks_master.zip'
$script = 'C:\temp\ansible\playbooks\roles\WIN2019-CIS\files\CIS_WindowsServer2016_2019_v110_MS_lvl1.ps1'
$BlobUri = 'https://armautomationartifacts.blob.core.windows.net/ansible-cis/ansible_playbooks_master.zip'
$FullUri = $BlobUri + $GenArtifactsSasToken

# Create File path if doesn't exist
if(!(Test-Path (Split-Path -Path $File))){
New-Item -ItemType directory -Path (Split-Path -Path $File) | out-null
Write-Host "#DATA#"
Write-Host "Directory path created"
Write-Host "#DATA#"
}

# Install Dependancies
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force
Set-PSRepository -Name 'PSGallery' -InstallationPolicy Trusted
install-module -Name NetworkingDsc -Force
install-module -Name AuditPolicyDsc -Force
install-module -Name SecurityPolicyDsc -Force

# Check if an existing file is there, if there is, it will be deleted to be able to download a fresh (latest version) copy   
if( (Get-ChildItem (Split-Path -Path $File) -Recurse -Force | Measure-Object).Count -eq 0)
{
 Write-Host "#DATA#"
 Write-Host "Directory path is empty"
 Write-Host "#DATA#"
} else { 
Get-ChildItem -Path (Split-Path -Path $File) -Recurse -Force | Remove-Item -Recurse -Force
 Write-Host "#DATA#"
 Write-Host "Path is NOW empty"
 Write-Host "#DATA#"
}

# Download ansible-cis/ansible_playbooks_master.zip
(New-Object System.Net.WebClient).DownloadFile($FullUri, $File)
Write-Host "#DATA#"
Write-Host "Ansible .ZIP file downloaded"
Write-Host "#DATA#"

# Unzip the files to the root of the directory
Expand-Archive -LiteralPath $File -DestinationPath (Split-Path -Path $File)
Write-Host "#DATA#"
Write-Host "Ansible .ZIP file extracted"
Write-Host "#DATA#"

# Execute the ansible playbook 
& $script | out-null
Write-Host "#DATA#"
Write-Host "CIS_WindowsServer2016_2019_v100_MS_lvl1 has been executed"
Write-Host "#DATA#"

Get-Date
$StopWatch.Stop()
$ElapsedTime = $StopWatch.Elapsed
Write-Host "#DATA#"
Write-Host "The script took" $ElapsedTime.Hours "hours," $ElapsedTime.Minutes "minutes, and" $ElapsedTime.Seconds "seconds to run."
Write-Host "#DATA#"

Write-Host "#DATA#"
Write-Host "FINISH SCRIPT"
Write-Host "#DATA#"
