Param  
(  
    [Parameter (Mandatory = $false)]  
    [object] $WebhookData  
)

[bool]$jobStatus = 0

try
{   
    # If runbook was called from Webhook, WebhookData will not be null.  
    if ($WebhookData) {  
        # Collect properties of WebhookData  
        $WebhookName = $WebHookData.WebhookName  
        $WebhookHeaders = $WebHookData.RequestHeader  
        $WebhookBody = $WebHookData.RequestBody  
        $Input = (ConvertFrom-Json -InputObject $WebhookBody)
        
        $Input
        
        # Instantiate Credentials
        $UserName = $Input.UserName
        $Password = ConvertTo-SecureString $Input.Password -AsPlainText -Force
        $psCred = New-Object System.Management.Automation.PSCredential -ArgumentList ($UserName, $Password)     
        
        $Session = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri https://outlook.office365.com/powershell-liveid/ -Credential $psCred -Authentication Basic -AllowRedirection
        
        $Input.DomainNames

        Import-PSSession $Session -DisableNameChecking
        if($Input.EmailAddresses -and $Input.DomainNames){              
            $EmailAddresses = $Input.EmailAddresses -split ","
            $DomainNames = $Input.DomainNames -split ","            
            Set-HostedContentFilterPolicy "Default" -AllowedSenders $EmailAddresses -AllowedSenderDomains $DomainNames
        }
        elseif($Input.EmailAddresses){              
            $EmailAddresses = $Input.EmailAddresses -split ","
            Set-HostedContentFilterPolicy "Default" -AllowedSenders $EmailAddresses
        }
        elseif($Input.DomainNames){
            $DomainNames = $Input.DomainNames -split ","
            Set-HostedContentFilterPolicy "Default" -AllowedSenderDomains $DomainNames
        }
        
        Remove-PSSession $Session
    }  
    else  
    {  
        Write-Error -Message 'Runbook was not started from Webhook' -ErrorAction stop  
    }    

}
Catch
{  
    "In Catch Block, Error Message Below...."
     $errorMessage = $_.Exception.Message  
     throw $errorMessage    
 
}
finally
{ 
    
}
