﻿$UserName="dnyanesh@dnyaneshtechno.onmicrosoft.com"
  
 $Password = ConvertTo-SecureString  "Password@1122" -AsPlainText -Force
  
 $URL="https://dnyaneshtechno.sharepoint.com/sites/oegsupport"
  
 $useSamePermissionsAsParentSite = $true
 $webURL = "Site Discription Test New"
 $title = "Site Discription Test New"
  
 $SPCredentials = New-Object -typename System.Management.Automation.PSCredential -argumentlist $UserName,$Password
  
 
  Connect-SPOService -Url https://dnyaneshtechno-admin.sharepoint.com -Credential $SPCredentials
   
       
 Import-Module "C:\Program Files\Common Files\microsoft shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
 Import-Module "C:\Program Files\Common Files\microsoft shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
  
     $SPOCredentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($UserName, $Password)
     $context = New-Object Microsoft.SharePoint.Client.ClientContext($URL)
     $context.Credentials = $SPOCredentials 
  
      #Specify Subsite details
    $WebCI = New-Object Microsoft.SharePoint.Client.WebCreationInformation
    $WebCI.Title = $title
    $WebCI.WebTemplate = "STS#0" #Team Site
    $WebCI.Url = $webURL
    $WebCI.useSamePermissionsAsParentSite = $useSamePermissionsAsParentSite
    #sharepoint online create subsite powershell
    $SubWeb = $Context.Web.Webs.Add($WebCI)
    $Context.ExecuteQuery()